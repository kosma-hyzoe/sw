import java.util.Arrays;

public class Partition {
	boolean checkPartition(int[] array, int n) {
		return 0;
	}

	public static void main(String[] args) {
		Judge.run(new Partition());
	}
}
