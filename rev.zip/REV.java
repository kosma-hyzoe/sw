import java.util.*;

public class REV {
	public int bitReverse(int value) {
		int res = -1;
		return res;
	}

	public static void main(String[] args) {
		Judge.run(new REV());
	}
}
