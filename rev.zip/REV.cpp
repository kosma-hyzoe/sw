#include "judge.h"
class REV : public IREV {
public:
	int bitReverse(int value) {
		int res = -1;
		return res;
	}
};

REV solution;
int main() {
	Judge::run(&solution);
	return 0;
}
