# Bit Reverse

Napisz funkcję `int bitReverse(int value)`, która odwróci kolejność bitów w liczbie `value`.

Przykład:

```
bitReverse(0); // => 0
bitReverse(1); // => -2147483648
bitReverse(2); // => 1073741824
bitReverse(3); // => -1073741824
bitReverse(4); // => 536870912
bitReverse(5); // => -1610612736
bitReverse(-1); // => -1
bitReverse(-2); // => 2147483647
bitReverse(-3); // => -1073741825
bitReverse(-4); // => 1073741823
bitReverse(-5); // => -536870913
bitReverse(-6); // => 1610612735
```
